
<?php include('header.php') ?>

<section class="listing_page body_padding">
<div class="main_heading">
    <h3 class="box-title text-center my-4"><span class="title">FORMALS</span></h3>
    </div>

    <div class="bread_crumb">

<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="index.php">Home</a></li>
    <li class="breadcrumb-item active" aria-current="page">FORMAL</li>
  </ol>
</nav>

    </div>

    <div class="sorting_area">
        <div class="d-flex justify-content-between">
            <div class="left_column d-flex">
                <p>View as</p>
                <div class="view-mode">
        <span class="icon-mode icon-mode-grid grid-2" data-col="2"></span>
        <span class="icon-mode icon-mode-grid grid-3" data-col="3"></span>
        <span class="icon-mode icon-mode-grid grid-4" data-col="4"></span>
        <span class="icon-mode icon-mode-grid grid-5" data-col="5"></span>
      </div>
            </div>
            <div class="right_column d-flex">
                <div class="items_per_page d-flex">
                <p>Items Per Page</p>
                <select name="" id="">
                    <option selected>12</option>
                    <option>15</option>
                    <option>20</option>
                    <option>25</option>
                </select>
                </div>
                <div class="sort_per_page d-flex">
                <p>Sort by</p>
                <select name="" id="">
                    <option selected>Featured</option>
                    <option>Price Low - High</option>
                    <option>Price High - Low</option>
                    <option>Best Selling</option>
                </select>
                </div>
            </div>
        </div>
    </div>
    <div class="products_cards">
        <div class="row">

            <div class="col-lg-3 col-md-4 col-sm-12 display_set">
<a href="detail.php">
<div class="item">
                   <div class="slider_image"> <img src="https://cdn.shopify.com/s/files/1/0517/8218/9242/files/Prints-_360X470_711b73ea-7484-467c-9b23-8177ba018fcb_1024x1024_crop_center.jpg?v=1636008002" alt=""></div>
                   <div class="img_inner_content">
                       <div class="wishlist-icon">
                       <p><a href=""><i class="fas fa-heart"></i></a></p>
                       </div>
                       <div class="sizing-icon d-flex justify-content-center">
                       <p><a href="">XS</a></p>
                       <p><a href="">M</a></p>
                       </div>
                       <div class="quick-buy">
                       <p><a href="#0" data-toggle="modal" data-target="#exampleModal">Quick Buy</a></p>
                       </div>
                   </div>
                    <div class="card-body text-center">
                        <p class="card-text">Rang Nagar (FR0432)</p>
                        <h5 class="card-title">Rs.9,500.00</h5>
                    </div>
                </div>
</a>
            </div>

            <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <div class="row">
          <div class="col-lg-6 col-md-6 col-sm-12 px-0 modal_content">
                <div class="d-flex justify-content-between">
                    <div class="main_img">
                    <img src="https://cdn.shopify.com/s/files/1/0517/8218/9242/products/DSC09399_80d9b754-31b1-404a-ad0f-7e1e86877dc6.jpg?v=1634550132" alt="">
                    </div>
                </div>
            </div>
      <div class="col-lg-6 col-md-6 col-sm-12 pl-md-4 modal_content">
                <div class="product_description">
            <h4 class="product-title">
                <span>Shisham (FR0434)</span>
            </h4>
            <div class="sku-product description_detail">
                <p>Product Code : 
                <span class="ml-4">FR043401</span>
                </p>
            </div>
            <h4 class="product-title mt-4">
                <span>Rs.7,250.00</span>
            </h4>
            <div class="description_detail">
                <p>Description : 
                <span>Full Sleeves Long Frock</span>
                </p>
            </div>
            <div class="description_detail">
                <p>Fabric : 
                <span>Lawn Karandi</span>
                </p>
            </div>
            <div class="description_detail">
                <p>Color : 
                <span>Yellow</span>
                </p>
            </div>
            <div class="description_detail">
                <p>PCS : 
                <span>1 PC</span>
                </p>
            </div>
            <div class="description_detail mt-3">
                <p>Size & Fit : <br> 
                <span>-Model Height Is 5'6.</span> <br>
                <span>-Model Is Wearing <strong>Small</strong> Size</span>
                </p>
            </div>
            <div class="description_detail mt-3">
                <p>SIZE : XS</p>
                <div class="box d-flex">
                <div class="sizes_label">
                        <input type="radio" name="radio"  class="variation_lg" id="xs">
                        <label for="xs">XS</label>
                        <input type="radio" name="radio" class="variation_lg" id="l">
                        <label for="l">L</label>
                        <input type="radio" name="radio"  class="variation_lg" id="s">
                        <label for="s">S</label>
                </div>
                </div>
            </div>

            <div class="button_group mt-4">
                <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12">
                        <button class="btn btn-outline-secondary w-100 py-2 text-uppercase font-weight-bold">Add to cart</button>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12">
                        <button class="btn btn-secondary w-100 py-2 text-uppercase wishlist_btn_sm font-weight-bold">Add to wishlist</button>
                    </div>
                </div>
            </div>
            </div>
            </div>
          </div>
          


      </div>
    </div>
  </div>
</div>

            <div class="col-lg-3 col-md-4 col-sm-12 display_set">
<div class="item">
                   <div class="slider_image"> <img src="https://cdn.shopify.com/s/files/1/0517/8218/9242/files/Prints-_360X470_711b73ea-7484-467c-9b23-8177ba018fcb_1024x1024_crop_center.jpg?v=1636008002" alt=""></div>
                   <div class="img_inner_content">
                       <div class="wishlist-icon">
                       <p><a href=""><i class="fas fa-heart"></i></a></p>
                       </div>
                       <div class="sizing-icon d-flex justify-content-center">
                       <p><a href="">XS</a></p>
                       <p><a href="">M</a></p>
                       </div>
                       <div class="quick-buy">
                       <p><a href="">Quick Buy</a></p>
                       </div>
                   </div>
                    <div class="card-body text-center">
                        <p class="card-text">Rang Nagar (FR0432)</p>
                        <h5 class="card-title">Rs.9,500.00</h5>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-12 display_set">
<div class="item">
                   <div class="slider_image"> <img src="https://cdn.shopify.com/s/files/1/0517/8218/9242/files/Prints-_360X470_711b73ea-7484-467c-9b23-8177ba018fcb_1024x1024_crop_center.jpg?v=1636008002" alt=""></div>
                   <div class="img_inner_content">
                       <div class="wishlist-icon">
                       <p><a href=""><i class="fas fa-heart"></i></a></p>
                       </div>
                       <div class="sizing-icon d-flex justify-content-center">
                       <p><a href="">XS</a></p>
                       <p><a href="">M</a></p>
                       </div>
                       <div class="quick-buy">
                       <p><a href="">Quick Buy</a></p>
                       </div>
                   </div>
                    <div class="card-body text-center">
                        <p class="card-text">Rang Nagar (FR0432)</p>
                        <h5 class="card-title">Rs.9,500.00</h5>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-12 display_set">
<div class="item">
                   <div class="slider_image"> <img src="https://cdn.shopify.com/s/files/1/0517/8218/9242/files/Prints-_360X470_711b73ea-7484-467c-9b23-8177ba018fcb_1024x1024_crop_center.jpg?v=1636008002" alt=""></div>
                   <div class="img_inner_content">
                       <div class="wishlist-icon">
                       <p><a href=""><i class="fas fa-heart"></i></a></p>
                       </div>
                       <div class="sizing-icon d-flex justify-content-center">
                       <p><a href="">XS</a></p>
                       <p><a href="">M</a></p>
                       </div>
                       <div class="quick-buy">
                       <p><a href="">Quick Buy</a></p>
                       </div>
                   </div>
                    <div class="card-body text-center">
                        <p class="card-text">Rang Nagar (FR0432)</p>
                        <h5 class="card-title">Rs.9,500.00</h5>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <hr>
    <div class="pagination_section d-flex justify-content-between">
        <div class="para">
            <p>Showing: 1 - 12 of 85</p>
        </div>
    <nav aria-label="Page navigation example">
  <ul class="pagination">
    <li class="page-item">
      <a class="page-link" href="#" aria-label="Previous">
        <span aria-hidden="true"><i class="far fa-chevron-left"></i></span>
      </a>
    </li>
    <li class="page-item"><a class="page-link" href="#">1</a></li>
    <li class="page-item"><a class="page-link" href="#">2</a></li>
    <li class="page-item"><a class="page-link" href="#">3</a></li>
    <li class="page-item">
      <a class="page-link" href="#" aria-label="Next">
        <span aria-hidden="true"><i class="far fa-chevron-right"></i></span>
      </a>
    </li>
  </ul>
</nav>
    </div>
</section>

<?php include('recentlyview.php') ?>

<?php include('footer.php') ?>

