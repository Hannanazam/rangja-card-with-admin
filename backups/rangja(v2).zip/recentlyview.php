
<section class="listing_page body_padding mt-4">
    <hr>
<div class="main_heading">
    <h3 class="box-title text-lg-left text-md-left my-4 text-sm-center" style="font-size:15px;font-weight:600;padding-left:15px;"><span class="title px-0">RECENTLY VIEWED PRODUCTS</span></h3>
    </div>
    <div class="products_cards">
        <div class="row">

            <div class="col-lg-3 col-md-4 col-sm-12 display_set">
<div class="item">
                   <div class="slider_image"> <img src="https://cdn.shopify.com/s/files/1/0517/8218/9242/files/Prints-_360X470_711b73ea-7484-467c-9b23-8177ba018fcb_1024x1024_crop_center.jpg?v=1636008002" alt=""></div>
                   <div class="img_inner_content">
                       <div class="wishlist-icon">
                       <p><a href=""><i class="fas fa-heart"></i></a></p>
                       </div>
                       <div class="sizing-icon d-flex justify-content-center">
                       <p><a href="">XS</a></p>
                       <p><a href="">M</a></p>
                       </div>
                       <div class="quick-buy">
                       <p><a href="">Quick Buy</a></p>
                       </div>
                   </div>
                    <div class="card-body text-center">
                        <p class="card-text">Rang Nagar (FR0432)</p>
                        <h5 class="card-title">Rs.9,500.00</h5>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4 col-sm-12 display_set">
<div class="item">
                   <div class="slider_image"> <img src="https://cdn.shopify.com/s/files/1/0517/8218/9242/files/Prints-_360X470_711b73ea-7484-467c-9b23-8177ba018fcb_1024x1024_crop_center.jpg?v=1636008002" alt=""></div>
                   <div class="img_inner_content">
                       <div class="wishlist-icon">
                       <p><a href=""><i class="fas fa-heart"></i></a></p>
                       </div>
                       <div class="sizing-icon d-flex justify-content-center">
                       <p><a href="">XS</a></p>
                       <p><a href="">M</a></p>
                       </div>
                       <div class="quick-buy">
                       <p><a href="">Quick Buy</a></p>
                       </div>
                   </div>
                    <div class="card-body text-center">
                        <p class="card-text">Rang Nagar (FR0432)</p>
                        <h5 class="card-title">Rs.9,500.00</h5>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>


